import { nanoid } from "nanoid"
console.log(nanoid(10));